package com.cart.dtos;

public record AuthPrincipal(Long userid, String username) {
}
