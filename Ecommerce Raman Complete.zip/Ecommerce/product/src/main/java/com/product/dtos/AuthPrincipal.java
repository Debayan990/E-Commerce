package com.product.dtos;

public record AuthPrincipal(Long userid, String username) {
}
