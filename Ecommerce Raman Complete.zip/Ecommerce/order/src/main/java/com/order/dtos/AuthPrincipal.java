package com.order.dtos;

public record AuthPrincipal(Long userid, String username) {
}
