package com.auth.dtos;

public record AuthPrincipal(Long userid,String username) {
}
